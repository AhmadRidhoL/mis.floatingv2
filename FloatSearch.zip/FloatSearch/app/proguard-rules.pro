# Aturan ProGuard/R8 tambahan untuk FloatSearch.
# Custom view dipakai dari XML; R8 otomatis mempertahankan konstruktor yang dirujuk layout,
# tetapi baris di bawah ini menjaga agar aman.
-keep class com.floatsearch.app.ui.view.** { *; }
