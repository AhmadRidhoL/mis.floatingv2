package com.floatsearch.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import com.floatsearch.app.R
import com.floatsearch.app.data.Prefs
import com.floatsearch.app.service.FloatingService
import com.floatsearch.app.util.applySystemBarsPadding
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var overlayStatus: TextView
    private lateinit var notifStatus: TextView
    private lateinit var serviceStatus: TextView
    private lateinit var btnOverlay: MaterialButton
    private lateinit var btnNotif: MaterialButton
    private lateinit var btnToggle: MaterialButton

    private val notifLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { refreshUi() }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.rootScroll).applySystemBarsPadding()

        prefs = Prefs(this)

        overlayStatus = findViewById(R.id.overlayStatus)
        notifStatus = findViewById(R.id.notifStatus)
        serviceStatus = findViewById(R.id.serviceStatus)
        btnOverlay = findViewById(R.id.btnOverlay)
        btnNotif = findViewById(R.id.btnNotif)
        btnToggle = findViewById(R.id.btnToggle)

        btnOverlay.setOnClickListener { openOverlaySettings() }
        btnNotif.setOnClickListener { requestNotificationPermission() }
        btnToggle.setOnClickListener { toggleService() }

        val themeGroup = findViewById<RadioGroup>(R.id.themeGroup)
        themeGroup.check(
            when (prefs.themeMode) {
                Prefs.THEME_LIGHT -> R.id.themeLight
                Prefs.THEME_DARK -> R.id.themeDark
                else -> R.id.themeSystem
            }
        )
        themeGroup.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.themeLight -> Prefs.THEME_LIGHT
                R.id.themeDark -> Prefs.THEME_DARK
                else -> Prefs.THEME_SYSTEM
            }
            if (mode != prefs.themeMode) {
                prefs.themeMode = mode
                if (FloatingService.isRunning) FloatingService.refresh(this)
                AppCompatDelegate.setDefaultNightMode(prefs.nightMode())
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun hasNotificationPermission(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

    private fun refreshUi() {
        val overlayOk = Settings.canDrawOverlays(this)
        overlayStatus.setText(
            if (overlayOk) R.string.status_overlay_ok else R.string.status_overlay_missing
        )
        btnOverlay.isEnabled = !overlayOk

        val notifOk = hasNotificationPermission()
        notifStatus.setText(
            if (notifOk) R.string.status_notif_ok else R.string.status_notif_missing
        )
        btnNotif.isEnabled = !notifOk

        val running = FloatingService.isRunning
        serviceStatus.setText(
            if (running) R.string.status_service_on else R.string.status_service_off
        )
        btnToggle.setText(if (running) R.string.btn_stop else R.string.btn_start)
    }

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun toggleService() {
        when {
            FloatingService.isRunning -> {
                FloatingService.stop(this)
                handler.postDelayed({ refreshUi() }, 300)
            }
            !Settings.canDrawOverlays(this) -> {
                Toast.makeText(this, R.string.toast_need_overlay, Toast.LENGTH_SHORT).show()
                openOverlaySettings()
            }
            else -> {
                if (!hasNotificationPermission()) requestNotificationPermission()
                FloatingService.start(this)
                handler.postDelayed({ refreshUi() }, 300)
            }
        }
    }
}
