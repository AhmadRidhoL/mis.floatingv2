package com.floatsearch.app.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.floatsearch.app.R
import com.floatsearch.app.data.Prefs
import com.floatsearch.app.ui.CaptureRequestActivity
import com.floatsearch.app.ui.PreviewActivity
import com.floatsearch.app.ui.view.PanelRootLayout
import com.floatsearch.app.util.CaptureContract
import com.floatsearch.app.util.NotificationHelper
import com.floatsearch.app.util.ScreenUtils
import com.floatsearch.app.util.SearchHelper
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Menampilkan tombol floating (bubble) yang bisa digeser ke seluruh sisi layar
 * dan panel menu berisi pencarian Google, copy/paste, serta tombol screenshot.
 */
class FloatingService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var themedContext: Context
    private val handler = Handler(Looper.getMainLooper())

    private var bubbleView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var bubbleW = 0
    private var bubbleH = 0

    private var panelView: PanelRootLayout? = null
    private var snapAnimator: ValueAnimator? = null
    private var receiverRegistered = false

    private val restoreBubbleRunnable = Runnable { setBubbleHiddenForCapture(false) }

    private val captureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            handler.removeCallbacks(restoreBubbleRunnable)
            setBubbleHiddenForCapture(false)

            val uriString = intent.getStringExtra(CaptureContract.EXTRA_URI)
            if (uriString != null) {
                openPreview(Uri.parse(uriString))
                return
            }
            when (intent.getStringExtra(CaptureContract.EXTRA_ERROR)) {
                CaptureContract.ERROR_CANCELLED -> toast(R.string.toast_capture_cancelled)
                CaptureContract.ERROR_BLOCKED -> toast(R.string.toast_capture_blocked)
                else -> toast(R.string.toast_capture_failed)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        ContextCompat.registerReceiver(
            this,
            captureReceiver,
            IntentFilter(CaptureContract.ACTION_RESULT),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        receiverRegistered = true
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        goForeground()

        if (!Settings.canDrawOverlays(this)) {
            toast(R.string.toast_need_overlay)
            stopSelf()
            return START_NOT_STICKY
        }

        if (intent?.action == ACTION_REFRESH) {
            rebuildOverlay()
        } else if (bubbleView == null) {
            showBubble()
        }
        return START_STICKY
    }

    private fun goForeground() {
        val notification = NotificationHelper.floatingNotification(this)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NotificationHelper.ID_FLOATING,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NotificationHelper.ID_FLOATING, notification)
        }
    }

    // ---------------------------------------------------------------- Tema

    /** Context untuk inflate view overlay, dengan mode terang/gelap sesuai pilihan pengguna. */
    private fun buildThemedContext(): Context {
        val config = Configuration(resources.configuration)
        val nightFlag = when (prefs.themeMode) {
            Prefs.THEME_LIGHT -> Configuration.UI_MODE_NIGHT_NO
            Prefs.THEME_DARK -> Configuration.UI_MODE_NIGHT_YES
            else -> config.uiMode and Configuration.UI_MODE_NIGHT_MASK
        }
        config.uiMode = (config.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or nightFlag
        return ContextThemeWrapper(
            createConfigurationContext(config),
            R.style.Theme_FloatSearch_Overlay
        )
    }

    private fun rebuildOverlay() {
        closePanel(animated = false)
        removeBubble()
        showBubble()
    }

    // -------------------------------------------------------------- Bubble

    private fun dp(value: Int) = ScreenUtils.dp(this, value)

    private fun bounds(): Rect {
        val dm = ScreenUtils.realMetrics(this)
        val ins = ScreenUtils.systemBarInsets(this)
        return Rect(
            0,
            ins.top,
            dm.widthPixels - bubbleW,
            dm.heightPixels - bubbleH - ins.bottom
        )
    }

    private fun clamp(params: WindowManager.LayoutParams) {
        val b = bounds()
        params.x = params.x.coerceIn(b.left, max(b.left, b.right))
        params.y = params.y.coerceIn(b.top, max(b.top, b.bottom))
    }

    private fun showBubble() {
        themedContext = buildThemedContext()
        val view = LayoutInflater.from(themedContext).inflate(R.layout.view_floating_bubble, null)
        view.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        bubbleW = view.measuredWidth
        bubbleH = view.measuredHeight

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        val b = bounds()
        params.x = if (prefs.bubbleX >= 0) prefs.bubbleX else b.right
        params.y = if (prefs.bubbleY >= 0) prefs.bubbleY else (b.bottom / 3)
        clamp(params)

        view.setOnClickListener { togglePanel() }
        attachBubbleTouch(view, params)

        windowManager.addView(view, params)
        bubbleView = view
        bubbleParams = params
    }

    private fun removeBubble() {
        snapAnimator?.cancel()
        bubbleView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: IllegalArgumentException) {
                // sudah dilepas
            }
        }
        bubbleView = null
        bubbleParams = null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachBubbleTouch(view: View, params: WindowManager.LayoutParams) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var dragging = false

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    startX = params.x
                    startY = params.y
                    downX = event.rawX
                    downY = event.rawY
                    dragging = false
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) {
                        dragging = true
                        closePanel()
                    }
                    if (dragging) {
                        params.x = (startX + dx).toInt()
                        params.y = (startY + dy).toInt()
                        clamp(params)
                        windowManager.updateViewLayout(v, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    if (event.actionMasked == MotionEvent.ACTION_UP) {
                        if (dragging) snapToEdge() else v.performClick()
                    }
                    true
                }
                else -> false
            }
        }
    }

    /** Menempelkan bubble ke sisi layar terdekat (kiri, kanan, atas, atau bawah). */
    private fun snapToEdge() {
        val view = bubbleView ?: return
        val params = bubbleParams ?: return
        val b = bounds()
        val left = params.x - b.left
        val right = b.right - params.x
        val top = params.y - b.top
        val bottom = b.bottom - params.y
        val nearest = minOf(left, right, top, bottom)

        val fromX = params.x
        val fromY = params.y
        var toX = fromX
        var toY = fromY
        when (nearest) {
            left -> toX = b.left
            right -> toX = max(b.left, b.right)
            top -> toY = b.top
            else -> toY = max(b.top, b.bottom)
        }

        snapAnimator?.cancel()
        snapAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                params.x = (fromX + (toX - fromX) * f).toInt()
                params.y = (fromY + (toY - fromY) * f).toInt()
                if (view.isAttachedToWindow) windowManager.updateViewLayout(view, params)
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    prefs.bubbleX = params.x
                    prefs.bubbleY = params.y
                }
            })
            start()
        }
    }

    // --------------------------------------------------------------- Panel

    private fun togglePanel() {
        if (panelView != null) closePanel() else openPanel()
    }

    private fun openPanel() {
        val bp = bubbleParams ?: return
        if (panelView != null) return

        val root = LayoutInflater.from(themedContext)
            .inflate(R.layout.view_floating_panel, null) as PanelRootLayout

        val dm = ScreenUtils.realMetrics(this)
        val ins = ScreenUtils.systemBarInsets(this)
        val margin = dp(8)
        val width = min(dp(328), dm.widthPixels - 2 * margin)

        root.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val height = root.measuredHeight

        // Posisi horizontal: sejajar bubble, tetap di dalam layar.
        val x = (bp.x + bubbleW / 2 - width / 2)
            .coerceIn(margin, max(margin, dm.widthPixels - width - margin))

        // Posisi vertikal: di bawah bubble jika muat di bagian atas layar
        // (agar tidak tertutup keyboard), selain itu di atas bubble.
        val belowY = bp.y + bubbleH
        val placeBelow = belowY + height <= dm.heightPixels * 0.55f ||
            bp.y - height < ins.top
        val rawY = if (placeBelow) belowY else bp.y - height
        val y = rawY.coerceIn(
            ins.top,
            max(ins.top, dm.heightPixels - ins.bottom - height)
        )

        val lp = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Tanpa FLAG_NOT_FOCUSABLE agar keyboard bisa mengetik di EditText.
            // FLAG_NOT_TOUCH_MODAL meneruskan sentuhan di luar panel ke aplikasi di bawahnya.
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        setupPanel(root)

        root.alpha = 0f
        root.scaleX = 0.9f
        root.scaleY = 0.9f
        root.pivotX = (bp.x + bubbleW / 2 - x).toFloat()
        root.pivotY = if (placeBelow) 0f else height.toFloat()

        windowManager.addView(root, lp)
        panelView = root

        root.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(160)
            .setInterpolator(DecelerateInterpolator())
            .start()

        val input = root.findViewById<EditText>(R.id.searchInput)
        root.postDelayed({
            input.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }, 220)
    }

    private fun setupPanel(root: PanelRootLayout) {
        val input = root.findViewById<EditText>(R.id.searchInput)

        root.onBackPressed = { closePanel() }
        root.findViewById<View>(R.id.btnPanelClose).setOnClickListener { closePanel() }
        root.findViewById<View>(R.id.btnClear).setOnClickListener { input.text.clear() }
        root.findViewById<View>(R.id.btnPaste).setOnClickListener { pasteInto(input) }
        root.findViewById<View>(R.id.btnCopy).setOnClickListener { copyFrom(input) }
        root.findViewById<View>(R.id.btnSearch).setOnClickListener {
            performSearch(input.text.toString())
        }
        root.findViewById<View>(R.id.btnScreenshot).setOnClickListener { startScreenshot() }
        root.findViewById<View>(R.id.btnStop).setOnClickListener { stopSelf() }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch(input.text.toString())
                true
            } else {
                false
            }
        }
    }

    private fun closePanel(animated: Boolean = true) {
        val view = panelView ?: return
        panelView = null

        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)

        if (animated) {
            view.animate()
                .alpha(0f)
                .scaleX(0.92f)
                .scaleY(0.92f)
                .setDuration(120)
                .withEndAction { removeViewSafely(view) }
                .start()
        } else {
            removeViewSafely(view)
        }
    }

    private fun removeViewSafely(view: View) {
        try {
            windowManager.removeView(view)
        } catch (e: IllegalArgumentException) {
            // sudah dilepas
        }
    }

    // ------------------------------------------------------------- Aksi

    private fun performSearch(query: String) {
        if (query.isBlank()) {
            toast(R.string.toast_empty_query)
            return
        }
        closePanel()
        if (!SearchHelper.open(this, query)) {
            toast(R.string.toast_no_browser)
        }
    }

    private fun pasteInto(input: EditText) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this)?.toString()
        } else {
            null
        }
        if (text.isNullOrEmpty()) {
            toast(R.string.toast_clipboard_empty)
            return
        }
        val start = max(input.selectionStart, 0)
        val end = max(input.selectionEnd, 0)
        input.text.replace(min(start, end), max(start, end), text)
    }

    private fun copyFrom(input: EditText) {
        val s = input.selectionStart
        val e = input.selectionEnd
        val text = if (s >= 0 && e > s) {
            input.text.substring(s, e)
        } else {
            input.text.toString()
        }
        if (text.isBlank()) {
            toast(R.string.toast_nothing_to_copy)
            return
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("FloatSearch", text))
        toast(R.string.toast_copied)
    }

    private fun startScreenshot() {
        closePanel()
        // Bubble dibuat transparan (bukan dihapus) agar tidak ikut tertangkap.
        setBubbleHiddenForCapture(true)
        handler.removeCallbacks(restoreBubbleRunnable)
        handler.postDelayed(restoreBubbleRunnable, 30_000)

        handler.postDelayed({
            val intent = Intent(this, CaptureRequestActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(intent)
            } catch (e: Exception) {
                handler.removeCallbacks(restoreBubbleRunnable)
                setBubbleHiddenForCapture(false)
                toast(R.string.toast_capture_failed)
            }
        }, 250)
    }

    private fun setBubbleHiddenForCapture(hidden: Boolean) {
        val view = bubbleView ?: return
        val params = bubbleParams ?: return
        view.animate().cancel()
        view.alpha = if (hidden) 0f else 1f
        params.flags = if (hidden) {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        }
        if (view.isAttachedToWindow) windowManager.updateViewLayout(view, params)
    }

    private fun openPreview(uri: Uri) {
        val intent = Intent(this, PreviewActivity::class.java)
            .setData(uri)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast(R.string.toast_capture_failed)
        }
    }

    private fun toast(resId: Int) {
        Toast.makeText(this, resId, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------- Lifecycle

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closePanel(animated = false)
        val view = bubbleView
        val params = bubbleParams
        if (view != null && params != null) {
            clamp(params)
            windowManager.updateViewLayout(view, params)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        closePanel(animated = false)
        removeBubble()
        if (receiverRegistered) {
            unregisterReceiver(captureReceiver)
            receiverRegistered = false
        }
        isRunning = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.floatsearch.app.action.STOP"
        const val ACTION_REFRESH = "com.floatsearch.app.action.REFRESH"

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, FloatingService::class.java)
            )
        }

        fun refresh(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, FloatingService::class.java).setAction(ACTION_REFRESH)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingService::class.java))
        }
    }
}
