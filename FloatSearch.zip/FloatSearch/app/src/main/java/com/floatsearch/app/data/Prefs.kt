package com.floatsearch.app.data

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

/** Penyimpanan pengaturan sederhana (tema dan posisi tombol floating). */
class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences(NAME, Context.MODE_PRIVATE)

    var themeMode: Int
        get() = sp.getInt(KEY_THEME, THEME_SYSTEM)
        set(value) {
            sp.edit().putInt(KEY_THEME, value).apply()
        }

    var bubbleX: Int
        get() = sp.getInt(KEY_X, -1)
        set(value) {
            sp.edit().putInt(KEY_X, value).apply()
        }

    var bubbleY: Int
        get() = sp.getInt(KEY_Y, -1)
        set(value) {
            sp.edit().putInt(KEY_Y, value).apply()
        }

    /** Konversi pilihan tema ke konstanta AppCompatDelegate. */
    fun nightMode(): Int = when (themeMode) {
        THEME_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
        THEME_DARK -> AppCompatDelegate.MODE_NIGHT_YES
        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    }

    companion object {
        private const val NAME = "floatsearch_prefs"
        private const val KEY_THEME = "theme_mode"
        private const val KEY_X = "bubble_x"
        private const val KEY_Y = "bubble_y"

        const val THEME_SYSTEM = 0
        const val THEME_LIGHT = 1
        const val THEME_DARK = 2
    }
}
