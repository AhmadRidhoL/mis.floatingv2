package com.floatsearch.app.ui

import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.floatsearch.app.service.ScreenCaptureService
import com.floatsearch.app.util.CaptureContract

/**
 * Activity transparan yang menampilkan dialog izin MediaProjection milik sistem,
 * lalu menjalankan ScreenCaptureService bila pengguna menyetujui.
 */
class CaptureRequestActivity : ComponentActivity() {

    private val launcher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            ContextCompat.startForegroundService(
                this,
                ScreenCaptureService.createIntent(this, result.resultCode, data)
            )
        } else {
            CaptureContract.sendError(this, CaptureContract.ERROR_CANCELLED)
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            launcher.launch(mpm.createScreenCaptureIntent())
        }
    }
}
