package com.floatsearch.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri

/** Kontrak broadcast internal antara ScreenCaptureService dan FloatingService. */
object CaptureContract {
    const val ACTION_RESULT = "com.floatsearch.app.action.CAPTURE_RESULT"
    const val EXTRA_URI = "extra_uri"
    const val EXTRA_ERROR = "extra_error"

    const val ERROR_CANCELLED = "cancelled"
    const val ERROR_BLOCKED = "blocked"
    const val ERROR_FAILED = "failed"

    fun sendSuccess(context: Context, uri: Uri) {
        send(context, Intent().putExtra(EXTRA_URI, uri.toString()))
    }

    fun sendError(context: Context, error: String) {
        send(context, Intent().putExtra(EXTRA_ERROR, error))
    }

    private fun send(context: Context, intent: Intent) {
        intent.action = ACTION_RESULT
        intent.setPackage(context.packageName)
        context.sendBroadcast(intent)
    }
}
