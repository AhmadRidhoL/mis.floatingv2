package com.floatsearch.app.ui.view

import android.content.Context
import android.util.AttributeSet
import android.view.KeyEvent
import android.widget.FrameLayout

/**
 * Root panel floating. Menangkap tombol Back agar panel bisa ditutup,
 * karena view di dalam WindowManager tidak punya Activity.onBackPressed().
 */
class PanelRootLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    var onBackPressed: (() -> Unit)? = null

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) {
                onBackPressed?.invoke()
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
