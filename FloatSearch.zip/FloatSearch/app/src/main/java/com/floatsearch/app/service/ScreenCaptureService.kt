package com.floatsearch.app.service

import android.app.Activity
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import com.floatsearch.app.util.CaptureContract
import com.floatsearch.app.util.NotificationHelper
import com.floatsearch.app.util.ScreenUtils
import com.floatsearch.app.util.ScreenshotSaver
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * Mengambil SATU screenshot memakai MediaProjection lalu berhenti.
 *
 * Android 14+ mewajibkan persetujuan pengguna untuk setiap sesi MediaProjection,
 * sehingga setiap screenshot meminta izin lewat CaptureRequestActivity.
 *
 * Layar yang dilindungi (FLAG_SECURE / DRM) akan menghasilkan frame hitam.
 * Service TIDAK mencoba melewatinya: hasil kosong dibuang dan pengguna diberi tahu.
 */
class ScreenCaptureService : Service() {

    private lateinit var workThread: HandlerThread
    private lateinit var workHandler: Handler
    private val mainHandler = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val started = AtomicBoolean(false)
    private val captured = AtomicBoolean(false)
    private val finished = AtomicBoolean(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        workThread = HandlerThread("FloatSearchCapture").also { it.start() }
        workHandler = Handler(workThread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Wajib memanggil startForeground (tipe mediaProjection) sebelum getMediaProjection().
        startForeground(
            NotificationHelper.ID_CAPTURE,
            NotificationHelper.captureNotification(this),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!started.compareAndSet(false, true)) return START_NOT_STICKY

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = readProjectionData(intent)
        if (resultCode != Activity.RESULT_OK || data == null) {
            finishWith(CaptureContract.ERROR_CANCELLED, null)
            return START_NOT_STICKY
        }

        // Beri waktu agar dialog izin sistem hilang dari layar sebelum menangkap.
        workHandler.postDelayed({ beginCapture(resultCode, data) }, START_DELAY_MS)
        // Pengaman bila frame tidak pernah datang.
        mainHandler.postDelayed(
            { finishWith(CaptureContract.ERROR_FAILED, null) },
            TIMEOUT_MS
        )
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readProjectionData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_DATA)
        }

    private fun beginCapture(resultCode: Int, data: Intent) {
        if (finished.get()) return
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val proj = mpm.getMediaProjection(resultCode, data)
            projection = proj

            // Android 14+ mewajibkan callback didaftarkan sebelum membuat VirtualDisplay.
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    releaseResources()
                }
            }, workHandler)

            val metrics = ScreenUtils.realMetrics(this)
            val width = metrics.widthPixels
            val height = metrics.heightPixels

            val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader = reader
            reader.setOnImageAvailableListener({ r -> onFrame(r) }, workHandler)

            virtualDisplay = proj.createVirtualDisplay(
                "FloatSearchCapture",
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                workHandler
            )
        } catch (e: Exception) {
            finishWith(CaptureContract.ERROR_FAILED, null)
        }
    }

    private fun onFrame(reader: ImageReader) {
        val image: Image? = try {
            reader.acquireLatestImage()
        } catch (e: Exception) {
            null
        }
        if (image == null) return

        if (finished.get() || !captured.compareAndSet(false, true)) {
            image.close()
            return
        }

        var bitmap: Bitmap? = null
        try {
            bitmap = imageToBitmap(image)
        } catch (e: Exception) {
            bitmap = null
        } finally {
            image.close()
        }

        if (bitmap == null) {
            finishWith(CaptureContract.ERROR_FAILED, null)
            return
        }

        // Layar yang menolak screen capture menghasilkan frame hitam polos.
        if (isBlank(bitmap)) {
            bitmap.recycle()
            finishWith(CaptureContract.ERROR_BLOCKED, null)
            return
        }

        val uri = ScreenshotSaver.save(this, bitmap)
        bitmap.recycle()
        if (uri == null) {
            finishWith(CaptureContract.ERROR_FAILED, null)
        } else {
            finishWith(null, uri)
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height
        val rowPadding = rowStride - pixelStride * width

        val padded = Bitmap.createBitmap(
            width + rowPadding / pixelStride,
            height,
            Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(plane.buffer)
        if (rowPadding == 0) return padded

        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return cropped
    }

    /** Mengecek sampel piksel: jika semuanya hitam, anggap layar tidak boleh ditangkap. */
    private fun isBlank(bitmap: Bitmap): Boolean {
        val stepX = max(1, bitmap.width / 24)
        val stepY = max(1, bitmap.height / 24)
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                if ((bitmap.getPixel(x, y) and 0x00FFFFFF) != 0) return false
                x += stepX
            }
            y += stepY
        }
        return true
    }

    private fun finishWith(error: String?, uri: android.net.Uri?) {
        if (!finished.compareAndSet(false, true)) return
        if (uri != null) {
            CaptureContract.sendSuccess(this, uri)
        } else {
            CaptureContract.sendError(this, error ?: CaptureContract.ERROR_FAILED)
        }
        releaseResources()
        mainHandler.post {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    @Synchronized
    private fun releaseResources() {
        try {
            virtualDisplay?.release()
        } catch (e: Exception) {
            // diabaikan
        }
        virtualDisplay = null

        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (e: Exception) {
            // diabaikan
        }
        imageReader = null

        val p = projection
        projection = null
        try {
            p?.stop()
        } catch (e: Exception) {
            // diabaikan
        }
    }

    override fun onDestroy() {
        finished.set(true)
        mainHandler.removeCallbacksAndMessages(null)
        releaseResources()
        workThread.quitSafely()
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_RESULT_CODE = "extra_result_code"
        private const val EXTRA_DATA = "extra_data"
        private const val START_DELAY_MS = 500L
        private const val TIMEOUT_MS = 8000L

        fun createIntent(context: Context, resultCode: Int, data: Intent): Intent =
            Intent(context, ScreenCaptureService::class.java)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
    }
}
