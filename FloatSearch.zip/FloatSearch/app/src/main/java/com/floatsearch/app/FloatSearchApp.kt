package com.floatsearch.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.floatsearch.app.data.Prefs

class FloatSearchApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Terapkan pilihan tema (sistem / terang / gelap) sejak aplikasi dimulai.
        AppCompatDelegate.setDefaultNightMode(Prefs(this).nightMode())
    }
}
