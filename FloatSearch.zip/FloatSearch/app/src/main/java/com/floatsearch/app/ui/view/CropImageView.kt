package com.floatsearch.app.ui.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Menampilkan bitmap (fit-center) dengan mode crop opsional:
 * kotak crop dapat digeser dan diubah ukurannya lewat sudut/sisi.
 */
class CropImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private enum class Mode { NONE, MOVE, TL, TR, BL, BR, LEFT, RIGHT, TOP, BOTTOM }

    private var bitmap: Bitmap? = null
    private val imageRect = RectF()
    private val cropRect = RectF()

    private val density = resources.displayMetrics.density
    private val touchRadius = 28f * density
    private val minSize = 72f * density

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint().apply { color = Color.argb(153, 0, 0, 0) }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(110, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private var mode = Mode.NONE
    private var lastX = 0f
    private var lastY = 0f

    var cropEnabled: Boolean = false
        set(value) {
            field = value
            if (value) resetCrop()
            invalidate()
        }

    fun setBitmap(bmp: Bitmap) {
        bitmap = bmp
        computeImageRect()
        resetCrop()
        invalidate()
    }

    /** Mengembalikan bagian bitmap yang berada di dalam kotak crop. */
    fun getCroppedBitmap(): Bitmap? {
        val bmp = bitmap ?: return null
        if (imageRect.width() <= 0f || imageRect.height() <= 0f) return null
        val scale = bmp.width / imageRect.width()
        val x = ((cropRect.left - imageRect.left) * scale).roundToInt().coerceIn(0, bmp.width - 1)
        val y = ((cropRect.top - imageRect.top) * scale).roundToInt().coerceIn(0, bmp.height - 1)
        val w = (cropRect.width() * scale).roundToInt().coerceIn(1, bmp.width - x)
        val h = (cropRect.height() * scale).roundToInt().coerceIn(1, bmp.height - y)
        return Bitmap.createBitmap(bmp, x, y, w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeImageRect()
        resetCrop()
    }

    private fun computeImageRect() {
        val bmp = bitmap
        if (bmp == null || width == 0 || height == 0) {
            imageRect.setEmpty()
            return
        }
        val scale = min(width / bmp.width.toFloat(), height / bmp.height.toFloat())
        val w = bmp.width * scale
        val h = bmp.height * scale
        val left = (width - w) / 2f
        val top = (height - h) / 2f
        imageRect.set(left, top, left + w, top + h)
    }

    private fun resetCrop() {
        val insetX = imageRect.width() * 0.1f
        val insetY = imageRect.height() * 0.1f
        cropRect.set(
            imageRect.left + insetX,
            imageRect.top + insetY,
            imageRect.right - insetX,
            imageRect.bottom - insetY
        )
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = bitmap ?: return
        canvas.drawBitmap(bmp, null, imageRect, bitmapPaint)
        if (!cropEnabled) return

        val c = cropRect
        val i = imageRect
        // Area gelap di luar kotak crop
        canvas.drawRect(i.left, i.top, i.right, c.top, dimPaint)
        canvas.drawRect(i.left, c.bottom, i.right, i.bottom, dimPaint)
        canvas.drawRect(i.left, c.top, c.left, c.bottom, dimPaint)
        canvas.drawRect(c.right, c.top, i.right, c.bottom, dimPaint)

        // Garis bantu 3x3
        val tw = c.width() / 3f
        val th = c.height() / 3f
        for (n in 1..2) {
            canvas.drawLine(c.left + tw * n, c.top, c.left + tw * n, c.bottom, gridPaint)
            canvas.drawLine(c.left, c.top + th * n, c.right, c.top + th * n, gridPaint)
        }

        canvas.drawRect(c, borderPaint)

        // Handle sudut dan tengah sisi
        val big = 8f * density
        val small = 5f * density
        canvas.drawCircle(c.left, c.top, big, handlePaint)
        canvas.drawCircle(c.right, c.top, big, handlePaint)
        canvas.drawCircle(c.left, c.bottom, big, handlePaint)
        canvas.drawCircle(c.right, c.bottom, big, handlePaint)
        canvas.drawCircle(c.centerX(), c.top, small, handlePaint)
        canvas.drawCircle(c.centerX(), c.bottom, small, handlePaint)
        canvas.drawCircle(c.left, c.centerY(), small, handlePaint)
        canvas.drawCircle(c.right, c.centerY(), small, handlePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!cropEnabled || bitmap == null) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = hitTest(event.x, event.y)
                lastX = event.x
                lastY = event.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return mode != Mode.NONE
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastX
                val dy = event.y - lastY
                lastX = event.x
                lastY = event.y
                applyDrag(dx, dy)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = Mode.NONE
            }
        }
        return true
    }

    private fun hitTest(x: Float, y: Float): Mode {
        val r = cropRect
        val t = touchRadius

        fun near(cx: Float, cy: Float) = hypot(x - cx, y - cy) <= t

        if (near(r.left, r.top)) return Mode.TL
        if (near(r.right, r.top)) return Mode.TR
        if (near(r.left, r.bottom)) return Mode.BL
        if (near(r.right, r.bottom)) return Mode.BR

        val withinX = x > r.left - t && x < r.right + t
        val withinY = y > r.top - t && y < r.bottom + t
        if (abs(x - r.left) <= t && withinY) return Mode.LEFT
        if (abs(x - r.right) <= t && withinY) return Mode.RIGHT
        if (abs(y - r.top) <= t && withinX) return Mode.TOP
        if (abs(y - r.bottom) <= t && withinX) return Mode.BOTTOM

        if (r.contains(x, y)) return Mode.MOVE
        return Mode.NONE
    }

    private fun applyDrag(dx: Float, dy: Float) {
        val r = cropRect
        val bounds = imageRect
        if (mode == Mode.NONE) return

        if (mode == Mode.MOVE) {
            val mx = dx.coerceIn(bounds.left - r.left, bounds.right - r.right)
            val my = dy.coerceIn(bounds.top - r.top, bounds.bottom - r.bottom)
            r.offset(mx, my)
            return
        }

        val moveLeft = mode == Mode.TL || mode == Mode.LEFT || mode == Mode.BL
        val moveRight = mode == Mode.TR || mode == Mode.RIGHT || mode == Mode.BR
        val moveTop = mode == Mode.TL || mode == Mode.TOP || mode == Mode.TR
        val moveBottom = mode == Mode.BL || mode == Mode.BOTTOM || mode == Mode.BR

        if (moveLeft) r.left = (r.left + dx).coerceIn(bounds.left, r.right - minSize)
        if (moveRight) r.right = (r.right + dx).coerceIn(r.left + minSize, bounds.right)
        if (moveTop) r.top = (r.top + dy).coerceIn(bounds.top, r.bottom - minSize)
        if (moveBottom) r.bottom = (r.bottom + dy).coerceIn(r.top + minSize, bounds.bottom)
    }
}
