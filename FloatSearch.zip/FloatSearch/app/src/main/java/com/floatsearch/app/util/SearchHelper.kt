package com.floatsearch.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

object SearchHelper {

    fun buildGoogleUri(query: String): Uri =
        Uri.parse("https://www.google.com/search")
            .buildUpon()
            .appendQueryParameter("q", query)
            .build()

    /**
     * Membuka hasil pencarian Google di browser.
     * Jika teks sudah berupa URL (http/https tanpa spasi) maka dibuka langsung.
     * @return false bila tidak ada browser yang dapat menangani.
     */
    fun open(context: Context, rawQuery: String): Boolean {
        val query = rawQuery.trim()
        val isUrl = (query.startsWith("http://") || query.startsWith("https://")) &&
            !query.contains(' ')
        val uri = if (isUrl) Uri.parse(query) else buildGoogleUri(query)
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        }
    }
}
