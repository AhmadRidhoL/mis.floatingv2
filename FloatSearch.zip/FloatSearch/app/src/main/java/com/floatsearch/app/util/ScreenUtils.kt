package com.floatsearch.app.util

import android.content.Context
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display
import kotlin.math.roundToInt

object ScreenUtils {

    fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).roundToInt()

    /** Ukuran layar nyata (termasuk area status bar / navigation bar) pada rotasi saat ini. */
    @Suppress("DEPRECATION")
    fun realMetrics(context: Context): DisplayMetrics {
        val metrics = DisplayMetrics()
        val dm = context.getSystemService(DisplayManager::class.java)
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(metrics)
        return metrics
    }

    /** Perkiraan inset system bar: top = status bar, bottom = navigation bar. */
    fun systemBarInsets(context: Context): Rect {
        val metrics = realMetrics(context)
        val landscape = metrics.widthPixels > metrics.heightPixels
        val top = dimen(context, "status_bar_height")
        val bottom = if (landscape) 0 else dimen(context, "navigation_bar_height")
        return Rect(0, top, 0, bottom)
    }

    private fun dimen(context: Context, name: String): Int {
        val id = context.resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) context.resources.getDimensionPixelSize(id) else 0
    }
}
