package com.floatsearch.app.ui

import android.content.ClipData
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.floatsearch.app.R
import com.floatsearch.app.ui.view.CropImageView
import com.floatsearch.app.util.ScreenshotSaver
import com.floatsearch.app.util.applySystemBarsPadding
import kotlin.concurrent.thread

/** Preview screenshot dengan fitur crop dan share. Hasil sudah tersimpan di galeri. */
class PreviewActivity : AppCompatActivity() {

    private lateinit var cropView: CropImageView
    private lateinit var previewActions: View
    private lateinit var cropActions: View

    private var currentUri: Uri? = null
    private var currentBitmap: Bitmap? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview)
        findViewById<View>(R.id.previewRoot).applySystemBarsPadding()

        cropView = findViewById(R.id.cropView)
        previewActions = findViewById(R.id.previewActions)
        cropActions = findViewById(R.id.cropActions)

        val uri = intent.data
        if (uri == null) {
            finish()
            return
        }
        currentUri = uri
        loadBitmap(uri)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnDone).setOnClickListener { finish() }
        findViewById<View>(R.id.btnShare).setOnClickListener { shareCurrent() }
        findViewById<View>(R.id.btnCrop).setOnClickListener { setCropMode(true) }
        findViewById<View>(R.id.btnCropCancel).setOnClickListener { setCropMode(false) }
        findViewById<View>(R.id.btnCropApply).setOnClickListener { applyCrop() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (cropView.cropEnabled) {
                    setCropMode(false)
                } else {
                    finish()
                }
            }
        })
    }

    private fun loadBitmap(uri: Uri) {
        thread {
            try {
                val source = ImageDecoder.createSource(contentResolver, uri)
                val bitmap = ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    // Software bitmap agar bisa di-crop dan dikompres ulang.
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    currentBitmap = bitmap
                    cropView.setBitmap(bitmap)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    toast(R.string.toast_load_failed)
                    finish()
                }
            }
        }
    }

    private fun setCropMode(enabled: Boolean) {
        cropView.cropEnabled = enabled
        previewActions.visibility = if (enabled) View.GONE else View.VISIBLE
        cropActions.visibility = if (enabled) View.VISIBLE else View.GONE
    }

    private fun applyCrop() {
        if (busy) return
        val cropped = try {
            cropView.getCroppedBitmap()
        } catch (e: Exception) {
            null
        }
        if (cropped == null) {
            toast(R.string.toast_save_failed)
            return
        }
        busy = true
        thread {
            val newUri = ScreenshotSaver.save(applicationContext, cropped)
            runOnUiThread {
                busy = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (newUri != null) {
                    currentUri = newUri
                    currentBitmap = cropped
                    cropView.setBitmap(cropped)
                    setCropMode(false)
                    toast(R.string.toast_crop_saved)
                } else {
                    toast(R.string.toast_save_failed)
                }
            }
        }
    }

    private fun shareCurrent() {
        val uri = currentUri ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, getString(R.string.share_title)))
    }

    private fun toast(resId: Int) {
        Toast.makeText(this, resId, Toast.LENGTH_SHORT).show()
    }
}
