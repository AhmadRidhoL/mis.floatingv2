# FloatSearch

Floating assistant untuk Android (Kotlin): tombol melayang di atas aplikasi lain, pencarian Google, dan screenshot via MediaProjection.

- Min SDK 29 (Android 10), target/compile SDK 35 (Android 15)
- Bahasa: Kotlin, UI berbasis XML (View system), tanpa library pihak ketiga selain AndroidX dan Material

## Struktur project

```
FloatSearch/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/floatsearch/app/
        │   ├── FloatSearchApp.kt              # Application: terapkan tema
        │   ├── data/Prefs.kt                  # Tema + posisi tombol
        │   ├── service/
        │   │   ├── FloatingService.kt         # Bubble, panel menu, pencarian, copy/paste
        │   │   └── ScreenCaptureService.kt    # MediaProjection -> bitmap -> MediaStore
        │   ├── ui/
        │   │   ├── MainActivity.kt            # Izin, start/stop, pilihan tema
        │   │   ├── CaptureRequestActivity.kt  # Dialog izin screen capture
        │   │   ├── PreviewActivity.kt         # Preview, crop, share
        │   │   └── view/ (CropImageView, PanelRootLayout)
        │   └── util/ (ScreenUtils, ScreenshotSaver, SearchHelper,
        │              NotificationHelper, CaptureContract, ViewInsets)
        └── res/ (layout, drawable, values, values-night, mipmap-anydpi)
```

## Cara build

Kebutuhan: **Android Studio Ladybug (2024.2) atau lebih baru**, JDK 17 (bawaan Android Studio), Android SDK Platform 35.

1. Buka Android Studio, pilih **File > Open**, lalu pilih folder `FloatSearch`.
2. Tunggu Gradle Sync selesai (butuh internet untuk mengunduh Gradle 8.9 dan dependensi).
3. Build APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Debug: `app/build/outputs/apk/debug/app-debug.apk`
   - Release: pilih variant `release` (sudah ditandatangani dengan debug key agar bisa langsung dipasang; ganti dengan keystore sendiri sebelum dipublikasikan).
4. Lewat terminal (setelah sync pertama): `gradle assembleDebug`, atau jalankan `gradle wrapper` sekali untuk membuat `gradlew`.

Pasang ke perangkat: `adb install -r app/build/outputs/apk/debug/app-debug.apk`, atau tekan **Run** di Android Studio.

> Catatan: file `gradle-wrapper.jar` dan skrip `gradlew` tidak disertakan (file biner). Android Studio tidak memerlukannya.

## Cara pakai

1. Buka FloatSearch, tekan **Berikan izin** pada "Tampil di atas aplikasi lain", aktifkan untuk FloatSearch, lalu kembali.
2. (Android 13+) Izinkan notifikasi agar notifikasi foreground service terlihat.
3. Tekan **Aktifkan tombol floating**. Tombol bulat muncul di atas aplikasi lain.
4. Seret tombol ke mana saja. Setelah dilepas, tombol menempel ke sisi layar terdekat (kiri, kanan, atas, atau bawah). Posisinya diingat.
5. Ketuk tombol untuk membuka/menutup panel:
   - **Cari**: ketik kata kunci lalu tekan Enter di keyboard atau tombol Cari. Hasil Google terbuka di browser. Tombol **Tempel** dan **Salin** memakai clipboard.
   - **Screenshot layar**: muncul dialog izin sistem, setujui, lalu preview terbuka. Di preview ada **Crop**, **Bagikan**, dan **Selesai**.
6. Untuk menonaktifkan: tombol **Tutup FloatSearch** di panel, tombol **Matikan** di notifikasi, atau di layar utama.

Screenshot disimpan otomatis di galeri, album `Pictures/FloatSearch` (lewat MediaStore, tanpa izin storage). Hasil crop disimpan sebagai file baru; file asli tidak diubah.

## Izin yang dipakai

| Izin | Fungsi |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Menampilkan tombol dan panel di atas aplikasi lain (diberikan manual di Settings) |
| `FOREGROUND_SERVICE` + `_SPECIAL_USE` | Menjaga floating service tetap hidup |
| `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Service pengambil screenshot |
| `POST_NOTIFICATIONS` | Notifikasi foreground service (Android 13+) |
| MediaProjection | Dialog izin dari sistem pada setiap screenshot |

## Batasan penting

- **Layar yang dilindungi tidak bisa di-screenshot** (FLAG_SECURE, DRM, banyak aplikasi perbankan atau streaming). FloatSearch tidak mencoba melewatinya. Jika hasil tangkapan hitam polos, hasil dibuang dan muncul pemberitahuan.
- **Izin screenshot diminta setiap kali.** Android 14+ mewajibkan persetujuan baru untuk setiap sesi MediaProjection.
- Jika layar benar-benar hitam polos secara sah, deteksi bisa salah mengira layar dilindungi.
- Beberapa merek (Xiaomi, Oppo, Vivo, Huawei, dll.) memiliki izin tambahan seperti "Tampilkan pop-up saat berjalan di latar belakang" dan penghemat baterai yang bisa mematikan service. Aktifkan izin tersebut dan matikan optimasi baterai untuk FloatSearch bila tombol hilang.
- Tipe foreground service `specialUse` cocok untuk sideload. Untuk Google Play, Anda perlu mengisi deklarasi penggunaan foreground service.
- Ikon launcher dan ikon UI berupa vector sederhana. Ganti sesuai kebutuhan.

## Pemecahan masalah

- **Tombol tidak muncul**: pastikan izin overlay aktif dan service berstatus aktif di layar utama.
- **Keyboard tidak muncul di panel**: ketuk kolom pencarian sekali.
- **Screenshot gagal berulang**: coba dari layar lain; jika selalu gagal pada satu aplikasi, aplikasi itu kemungkinan memblokir screen capture.
- **Sync Gradle gagal**: pastikan memakai JDK 17 (Settings > Build Tools > Gradle > Gradle JDK) dan SDK Platform 35 terpasang.
